'use client';

import { SliderDemo } from '@/components/slide';
import { ThemeToggle } from '@/components/theme-toggle';
import { Button } from '@/components/ui/button';
import {
	Card,
	CardContent,
	CardFooter,
	CardHeader,
	CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { redirect } from 'next/navigation';
import { useState } from 'react';

export default function ExamSetting() {
	const [studentName, setStudentName] = useState('');
	const [tasksCount, setTasksCount] = useState(30);
	const [timeTaken, setTimeTaken] = useState(40);

	return (
		<main className='flex items-center justify-center h-screen flex-col'>
			<ThemeToggle className='mb-5' mode='light-dark' />
			<form className=''>
				<Card className='w-95 sm:w-150 h-100 text-3xl'>
					<CardHeader>
						<CardTitle className='text-center'>
							Настройте свое тестирование
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className='grid w-full items-center gap-4'>
							<div className='flex flex-col space-y-1.5'>
								<Label className='text-2xl' htmlFor='name'>
									Имя{' '}
									{!studentName && (
										<p className='text-red-600 text-sm '>Заполните это поле</p>
									)}
								</Label>
								<Input
									id='name'
									placeholder='Ваше имя'
									onChange={e => setStudentName(e.target.value)}
									className={cn(
										'h-10',
										!studentName && 'border-solid border-red-600 border-1'
									)}
									required
								/>
							</div>
							<div className='flex flex-col space-y-1.5'>
								<Label className='text-2xl' htmlFor='tasksCount'>
									Кол-во заданий: {tasksCount}
								</Label>
								<SliderDemo
									defaultValue={[30]}
									max={50}
									min={10}
									step={10}
									onValueChange={value => setTasksCount(value[0])}
									className={cn('w-[100%]')}
								/>
							</div>
							<div className='flex flex-col space-y-1.5'>
								<Label className='text-2xl' htmlFor='tasksCount'>
									Уделенное время: {timeTaken} минут
								</Label>
								<SliderDemo
									defaultValue={[40]}
									max={50}
									min={10}
									step={10}
									onValueChange={value => setTimeTaken(value[0])}
									className={cn('w-[100%]')}
								/>
							</div>
						</div>
					</CardContent>
					<CardFooter className='flex justify-between'>
						<Button
							variant='outline'
							onClick={() => redirect('/')}
							className='w-30 h-10 text-2xl'
						>
							Назад
						</Button>
						<Button type='submit' className='w-30 h-10 text-2xl'>
							Начать
						</Button>
					</CardFooter>
				</Card>
			</form>
		</main>
	);
}
