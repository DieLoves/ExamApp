'use client';

import { ConfirmExamFinish } from '@/components/confirm-exam-end';
import { Button } from '@/components/ui/button';
import {
	Card,
	CardContent,
	CardFooter,
	CardHeader,
	CardTitle,
} from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { shuffle } from '@/lib/utils';
import { IExamFileQuestions } from '@/types/exam.types';
import { Fragment, useEffect, useState } from 'react';
import allQuestions from '../../../public/output.json';

const QuestionTitle = ({ title }: { title: string }) => {
	const lines = title.split('\n').map((line, index) => (
		<Fragment key={index}>
			{line}
			{index < title.split('\n').length - 1 && <br />}
		</Fragment>
	));

	return <div>{lines}</div>;
};

export default function Page() {
	const [questions, setQuestions] = useState<IExamFileQuestions[]>([]);
	const [currentQuestion, setCurrentQuestion] = useState(0);
	const [selectedAnswers, setSelectedAnswers] = useState([]);
	const [isFinished, setIsFinished] = useState(false);
	const [finalScore, setFinalScore] = useState(0);
	const [isLastQuestion, setIsLastQuestion] = useState(false);

	const handleNextQuestion = () => {
		if (isLastQuestion) {
			setIsFinished(true);
			setCurrentQuestion(currentQuestion + 1);
		} else {
			if (currentQuestion + 1 === questions.length - 1) {
				setIsLastQuestion(true);
			}
			setCurrentQuestion(currentQuestion + 1);
		}
	};

	const handlePrevQuestion = () => {
		setCurrentQuestion(currentQuestion - 1);
		setIsLastQuestion(false);
	};
	useEffect(() => {
		const q = shuffle<IExamFileQuestions>(allQuestions.questions).slice(0, 30);
		setQuestions(q);
		console.log(q);
	}, []);

	return (
		<div className='h-screen flex justify-center items-center'>
			{questions.length > 0 && (
				<Card className='w-95 sm:w-150 h-fit text-3xl'>
					<CardHeader>
						<CardTitle className='text-center'>
							Настройте свое тестирование
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div>
							<h1 className='text-center text-4xl mb-3'>
								Вопрос {currentQuestion + 1}
							</h1>
							<h3 className='text-2xl sm:text-3xl'>
								<QuestionTitle title={questions[currentQuestion].title} />
							</h3>
							<RadioGroup className='mt-5'>
								{questions[currentQuestion].answers.map((question, i) => (
									<div
										key={`question_${i}`}
										className='flex items-center space-x-2'
									>
										<RadioGroupItem
											value={`question_${currentQuestion}_${i}`}
											id={`r${i}`}
										/>
										<Label className='text-xl sm:text-2xl' htmlFor={`r${i}`}>
											{question.text}
										</Label>
									</div>
								))}
							</RadioGroup>
						</div>
					</CardContent>
					<CardFooter className='flex justify-between'>
						<Button
							variant='outline'
							className='w-30 h-10 text-2xl'
							onClick={handlePrevQuestion}
							disabled={currentQuestion < 1}
						>
							Назад
						</Button>
						{isLastQuestion ? (
							<ConfirmExamFinish isFinish={isFinished} />
						) : ( 
							<>
								{isFinished && <ConfirmExamFinish isFinish={isFinished} />}
								<Button
									className='w-30 h-10 text-xl'
									onClick={handleNextQuestion}
								>
									Далее
								</Button>
							</>
						)}
						{/* {isFinished && currentQuestion !== questions.length - 1 && (
							<>
								<ConfirmExamFinish isFinish={isFinished} />
								<Button
									className='w-30 h-10 text-xl'
									onClick={handleNextQuestion}
								>
									Далее
								</Button>
							</>
						)}
						{currentQuestion <= questions.length - 1 && isFinished ? (
							<ConfirmExamFinish isFinish={isFinished} />
						) : (
							<Button
								className='w-30 h-10 text-xl'
								onClick={handleNextQuestion}
							>
								Далее
							</Button>
						)} */}
					</CardFooter>
				</Card>
			)}
		</div>
	);
}
