'use client';

import { ThemeToggle } from '@/components/theme-toggle';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

export default function Home() {
	const router = useRouter();

	return (
		<main className='flex items-center justify-center h-screen flex-col gap-5'>
			<ThemeToggle className='' mode='light-dark' />
			<h1 className='text-5xl text-center sm:text-6xl'>Привет.</h1>
			<h2 className='text-3xl text-center sm:text-5xl mt-0 mb-5'>
				Готов к тестированию?
			</h2>
			<Button
				className='h-15 w-50 text-3xl'
				onClick={() => router.push('/exam/settings')}
			>
				Начать!
			</Button>
		</main>
	);
}
