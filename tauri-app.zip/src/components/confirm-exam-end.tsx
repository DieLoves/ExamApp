import {
	AlertDialog,
	AlertDialogAction,
	AlertDialogCancel,
	AlertDialogContent,
	AlertDialogDescription,
	AlertDialogTitle,
	AlertDialogTrigger,
} from '@radix-ui/react-alert-dialog';
import { AlertDialogFooter, AlertDialogHeader } from './ui/alert-dialog';
import { Button } from './ui/button';

export function ConfirmExamFinish({ isFinish }: { isFinish: boolean }) {
	return (
		<AlertDialog>
			<AlertDialogTrigger asChild>
				<Button className='w-30 h-10 text-xl'>Закончить</Button>
			</AlertDialogTrigger>
			<AlertDialogContent>
				<AlertDialogHeader>
					<AlertDialogTitle>Вы уверены?</AlertDialogTitle>
					{!isFinish && (
						<AlertDialogDescription>
							Вы еще не ответили на все вопросы
						</AlertDialogDescription>
					)}
				</AlertDialogHeader>
				<AlertDialogFooter>
					<AlertDialogCancel>Отменить</AlertDialogCancel>
					<AlertDialogAction>Закончить тестирование</AlertDialogAction>
				</AlertDialogFooter>
			</AlertDialogContent>
		</AlertDialog>
	);
}
