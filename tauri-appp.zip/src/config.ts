// Конфигурационный файл для выбора версии приложения
export const APP_VERSION = process.env.NEXT_PUBLIC_APP_VERSION || 'tech';
export const APP_NAME =
	APP_VERSION === 'tech' ? 'Техник версия' : 'Гуманитарная версия';
export const DATA_FILE = APP_VERSION === 'tech' ? '/tech.json' : '/human.json';
