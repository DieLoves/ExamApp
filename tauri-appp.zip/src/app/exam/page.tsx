'use client';

import { cn } from '@/lib/utils';

import { AnswerOption } from '@/components/answer-option';
import { ConfirmExamFinish } from '@/components/confirm-exam-end';
import { Pagination } from '@/components/pagination';
import { QuestionTitle } from '@/components/question-title';
import { ReviewAnswer } from '@/components/review-answer';
import { SettingsButton } from '@/components/settings-button';
import { Timer, formatElapsedTime } from '@/components/timer';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { shuffle } from '@/lib/utils';
import type { IExamFileQuestions, QuestionAnswer } from '@/types/exam.types';
import { Calendar, CheckCircle, Clock, User, XCircle } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
// Импортируем конфигурацию вместо прямого импорта файла
import { DATA_FILE } from '@/config';
import {
	clearExamProgress,
	loadExamSettings,
	saveExamProgress,
	saveExamResult,
	type ExamProgress,
} from '@/lib/tauri-store';

// Interface for shuffled questions with original answer indices
interface ShuffledQuestion extends Omit<IExamFileQuestions, 'answers'> {
	answers: (QuestionAnswer & { originalIndex: number })[];
}

interface ExamSettings {
	studentName: string;
	tasksCount: number;
	timeTaken: number;
}

export default function Page() {
	const router = useRouter();
	const [settings, setSettings] = useState<ExamSettings | null>(null);
	const [questions, setQuestions] = useState<ShuffledQuestion[]>([]);
	const [currentQuestion, setCurrentQuestion] = useState(0);
	const [selectedAnswers, setSelectedAnswers] = useState<
		Record<number, number>
	>({});
	// Track original answer indices for scoring
	const [selectedOriginalAnswers, setSelectedOriginalAnswers] = useState<
		Record<number, number>
	>({});
	const [isFinished, setIsFinished] = useState(false);
	const [finalScore, setFinalScore] = useState(0);
	const [pointsScore, setPointsScore] = useState(0);
	const [gradeScore, setGradeScore] = useState(0);
	const [showResults, setShowResults] = useState(false);
	const [showReview, setShowReview] = useState(false);
	const [progress, setProgress] = useState(0);
	const [reviewQuestion, setReviewQuestion] = useState(0);
	const [startTime, setStartTime] = useState<Date | null>(null);
	const [endTime, setEndTime] = useState<Date | null>(null);
	const [timeSpent, setTimeSpent] = useState(0);
	const [isLoading, setIsLoading] = useState(true);
	const [examDate, setExamDate] = useState<string | null>(null);

	// Сохранение прогресса при уходе со страницы
	useEffect(() => {
		// Функция для сохранения прогресса
		const saveProgress = async () => {
			if (questions.length === 0 || isFinished) return;

			const progress: ExamProgress = {
				currentQuestion,
				selectedAnswers,
				selectedOriginalAnswers,
				startTime: startTime
					? startTime.toISOString()
					: new Date().toISOString(),
				progress: calculateProgressValue(),
				questions: questions,
			};

			await saveExamProgress(progress);
		};

		// Сохраняем прогресс при уходе со страницы
		const handleBeforeUnload = () => {
			saveProgress();
		};

		window.addEventListener('beforeunload', handleBeforeUnload);

		// Сохраняем прогресс каждые 10 секунд
		const intervalId = setInterval(() => {
			saveProgress();
		}, 10000);

		return () => {
			window.removeEventListener('beforeunload', handleBeforeUnload);
			clearInterval(intervalId);
			saveProgress();
		};
	}, [
		questions,
		currentQuestion,
		selectedAnswers,
		selectedOriginalAnswers,
		startTime,
		isFinished,
	]);

	const handleAnswerSelect = (answerIndex: number) => {
		const originalIndex =
			questions[currentQuestion].answers[answerIndex].originalIndex;

		setSelectedAnswers(prev => ({
			...prev,
			[currentQuestion]: answerIndex,
		}));

		setSelectedOriginalAnswers(prev => ({
			...prev,
			[currentQuestion]: originalIndex,
		}));
	};

	const handleNextQuestion = () => {
		if (currentQuestion < questions.length - 1) {
			setCurrentQuestion(currentQuestion + 1);
		} else {
			handleFinishExam();
		}
		updateProgress();
	};

	const handlePrevQuestion = () => {
		if (currentQuestion > 0) {
			setCurrentQuestion(currentQuestion - 1);
		}
		updateProgress();
	};

	const handleJumpToQuestion = (index: number) => {
		setCurrentQuestion(index);
	};

	const handleJumpToReviewQuestion = (index: number) => {
		setReviewQuestion(index);
	};

	const handleNextReviewQuestion = () => {
		if (reviewQuestion < questions.length - 1) {
			setReviewQuestion(reviewQuestion + 1);
		}
	};

	const handlePrevReviewQuestion = () => {
		if (reviewQuestion > 0) {
			setReviewQuestion(reviewQuestion - 1);
		}
	};

	const calculateProgressValue = () => {
		if (questions.length === 0) {
			return 0;
		}

		const answeredCount = Object.keys(selectedAnswers).length;
		const progressValue = (answeredCount / questions.length) * 100;
		return isNaN(progressValue) ? 0 : progressValue;
	};

	const updateProgress = () => {
		setProgress(calculateProgressValue());
	};

	const handleFinishExam = async () => {
		if (!isFinished) {
			setIsFinished(true);
			const now = new Date();
			setEndTime(now);

			if (startTime) {
				const timeElapsed = Math.floor(
					(now.getTime() - startTime.getTime()) / 1000
				);
				setTimeSpent(timeElapsed);
			}

			calculateScore();
			setShowResults(true);

			// Очищаем сохраненный прогресс
			await clearExamProgress();

			// Сохраняем результаты последнего экзамена
			if (settings) {
				try {
					await saveExamResult({
						studentName: settings.studentName,
						date: examDate || now.toISOString(),
						score: finalScore,
						pointsScore: pointsScore,
						gradeScore: gradeScore,
						timeSpent: timeSpent,
						questionsCount: questions.length,
						correctAnswers: Math.round((finalScore / 100) * questions.length),
					});
				} catch (error) {
					console.error('Ошибка при сохранении результатов экзамена:', error);
				}
			}
		}
	};

	const handleTimeUp = () => {
		if (!isFinished) {
			handleFinishExam();
		}
	};

	const calculateScore = () => {
		let score = 0;
		Object.entries(selectedOriginalAnswers).forEach(
			([questionIdx, originalAnswerIdx]) => {
				const question = questions[Number.parseInt(questionIdx)];
				const originalAnswers = question.answers.filter(
					a => a.originalIndex === originalAnswerIdx
				);
				if (originalAnswers.length > 0 && originalAnswers[0].isCorrect) {
					score++;
				}
			}
		);

		const percentage =
			questions.length > 0 ? (score / questions.length) * 100 : 0;
		setFinalScore(percentage);

		// Calculate points out of 100
		const pointsOutOf100 = Math.round(percentage);
		setPointsScore(pointsOutOf100);

		// Calculate 5-point grade scale
		let grade = 2; // Default failing grade
		if (percentage >= 90) grade = 5;
		else if (percentage >= 75) grade = 4;
		else if (percentage >= 60) grade = 3;

		setGradeScore(grade);
	};

	const handleReturnHome = () => {
		router.push('/');
	};

	const handleShowReview = () => {
		setShowResults(false);
		setShowReview(true);
		setReviewQuestion(0);
	};

	const handleBackToResults = () => {
		setShowReview(false);
		setShowResults(true);
	};

	const isAnswerCorrect = (questionIndex: number) => {
		if (selectedOriginalAnswers[questionIndex] === undefined) {
			return false;
		}

		const originalAnswerIdx = selectedOriginalAnswers[questionIndex];
		const question = questions[questionIndex];
		const originalAnswers = question.answers.filter(
			a => a.originalIndex === originalAnswerIdx
		);

		return originalAnswers.length > 0 && originalAnswers[0].isCorrect;
	};

	const getUserAnswerStatus = (questionIndex: number) => {
		if (selectedAnswers[questionIndex] === undefined) {
			return 'Не отвечено';
		}

		return isAnswerCorrect(questionIndex) ? 'Правильно' : 'Неправильно';
	};

	// Инициализация нового экзамена
	useEffect(() => {
		const initExam = async () => {
			setIsLoading(true);

			try {
				// Загружаем настройки и инициализируем новый экзамен
				const savedSettings = await loadExamSettings();
				if (!savedSettings) {
					router.push('/exam/settings');
					return;
				}

				setSettings(savedSettings);

				// Set start time
				const now = new Date();
				setStartTime(now);
				setExamDate(now.toISOString());

				// Загружаем вопросы из выбранного файла
				const questionsData = await fetch(DATA_FILE).then(res => res.json());

				// Load and shuffle questions based on settings
				const questionCount = savedSettings.tasksCount || 30;
				const originalQuestions = shuffle<IExamFileQuestions>(
					questionsData.questions
				).slice(0, questionCount);

				// Shuffle answers and keep track of original indices
				const questionsWithShuffledAnswers: ShuffledQuestion[] =
					originalQuestions.map(q => {
						const answersWithIndices = q.answers.map((answer, index) => ({
							...answer,
							originalIndex: index,
						}));

						return {
							...q,
							answers: shuffle(answersWithIndices),
						};
					});

				setQuestions(questionsWithShuffledAnswers);
				setProgress(0);
			} catch (error) {
				console.error('Error initializing exam:', error);
				router.push('/exam/settings');
			} finally {
				setIsLoading(false);
			}
		};

		initExam();
	}, [router]);

	useEffect(() => {
		updateProgress();
	}, [selectedAnswers]);

	if (showReview) {
		const currentReviewQuestion = questions[reviewQuestion];
		const userAnswerIndex = selectedAnswers[reviewQuestion];
		const userAnswerStatus = getUserAnswerStatus(reviewQuestion);
		const statusColor =
			userAnswerStatus === 'Правильно'
				? 'text-green-500'
				: userAnswerStatus === 'Неправильно'
				? 'text-red-500'
				: 'text-yellow-500';

		return (
			<div className='min-h-screen flex flex-col bg-background'>
				<header className='sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b p-4 flex justify-between items-center'>
					<h1 className='text-xl font-semibold'>Просмотр ответов</h1>
					<SettingsButton />
				</header>

				<main className='flex-1 p-4'>
					<div className='flex flex-col sm:flex-row sm:justify-between sm:items-center mt-2 gap-2'>
						<span className='text-base'>
							Вопрос {reviewQuestion + 1} из {questions.length}
						</span>
						<span
							className={`text-base font-medium flex items-center gap-2 ${statusColor}`}
						>
							{userAnswerStatus === 'Правильно' ? (
								<CheckCircle className='h-4 w-4' />
							) : userAnswerStatus === 'Неправильно' ? (
								<XCircle className='h-4 w-4' />
							) : null}
							{userAnswerStatus}
						</span>
					</div>

					<Progress
						value={((reviewQuestion + 1) / questions.length) * 100}
						className='h-2 mt-2'
					/>

					<Pagination
						currentIndex={reviewQuestion}
						totalItems={questions.length}
						onSelect={handleJumpToReviewQuestion}
						selectedItems={selectedAnswers}
						isReview={true}
						isAnswerCorrect={isAnswerCorrect}
					/>

					<div className='mt-6'>
						<h3 className='text-lg sm:text-xl mb-4'>
							<QuestionTitle title={currentReviewQuestion.title} />
						</h3>
						<div className='mt-4 space-y-3'>
							{currentReviewQuestion.answers.map((answer, i) => (
								<ReviewAnswer
									key={`review-answer-${i}`}
									index={i}
									text={answer.text}
									isSelected={userAnswerIndex === i}
									isCorrect={answer.isCorrect}
								/>
							))}
						</div>
					</div>
				</main>

				<footer className='sticky bottom-0 z-10 bg-background/80 backdrop-blur-sm border-t p-4 flex flex-wrap justify-between gap-2'>
					<Button
						variant='outline'
						className='h-10 text-base'
						onClick={handlePrevReviewQuestion}
						disabled={reviewQuestion === 0}
					>
						Назад
					</Button>
					<Button
						variant='outline'
						className='h-10 text-base'
						onClick={handleBackToResults}
					>
						К результатам
					</Button>
					<Button
						className='h-10 text-base'
						onClick={handleNextReviewQuestion}
						disabled={reviewQuestion === questions.length - 1}
					>
						Далее
					</Button>
				</footer>
			</div>
		);
	}

	if (showResults) {
		return (
			<div className='min-h-screen flex flex-col bg-background'>
				<header className='sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b p-4 flex justify-between items-center'>
					<h1 className='text-xl font-semibold'>Результаты тестирования</h1>
					<SettingsButton />
				</header>

				<main className='flex-1 p-4'>
					{settings && (
						<div className='flex flex-col gap-2 mt-2 text-base'>
							<div className='flex items-center gap-2'>
								<User className='h-4 w-4' />
								<span>Студент: {settings.studentName}</span>
							</div>
							<div className='flex items-center gap-2'>
								<Calendar className='h-4 w-4' />
								<span>
									Дата:{' '}
									{endTime
										? new Intl.DateTimeFormat('ru-RU', {
												year: 'numeric',
												month: 'long',
												day: 'numeric',
												hour: '2-digit',
												minute: '2-digit',
										  }).format(endTime)
										: 'Не указана'}
								</span>
							</div>
							<div className='flex items-center gap-2'>
								<Clock className='h-4 w-4' />
								<span>Время выполнения: {formatElapsedTime(timeSpent)}</span>
							</div>
						</div>
					)}

					<div className='grid grid-cols-1 sm:grid-cols-3 gap-4 w-full mt-6'>
						<div className='flex flex-col items-center p-3 border rounded-lg'>
							<div className='text-base font-medium mb-1'>Процент</div>
							<div className='text-2xl sm:text-3xl font-bold'>
								{finalScore.toFixed(1)}%
							</div>
						</div>
						<div className='flex flex-col items-center p-3 border rounded-lg'>
							<div className='text-base font-medium mb-1'>Баллы</div>
							<div className='text-2xl sm:text-3xl font-bold'>
								{pointsScore}/100
							</div>
						</div>
						<div className='flex flex-col items-center p-3 border rounded-lg'>
							<div className='text-base font-medium mb-1'>Оценка</div>
							<div className='text-2xl sm:text-3xl font-bold'>
								{gradeScore}/5
							</div>
						</div>
					</div>

					<div className='text-lg sm:text-xl mt-6'>
						Правильных ответов:{' '}
						{Math.round((finalScore / 100) * questions.length)} из{' '}
						{questions.length}
					</div>
					<Progress value={finalScore} className='w-full h-3 mt-2' />

					<div className='w-full mt-6'>
						<h3 className='text-base sm:text-lg mb-2'>
							Результаты по вопросам:
						</h3>
						<div className='flex flex-wrap gap-2 justify-center'>
							{Array.from({ length: questions.length }).map((_, index) => {
								const isAnswered = selectedAnswers[index] !== undefined;
								const isCorrect = isAnswerCorrect(index);

								return (
									<div
										key={`result-${index}`}
										className={cn(
											'h-8 w-8 rounded-full text-sm flex items-center justify-center',
											isAnswered && isCorrect
												? 'bg-green-500 text-white'
												: isAnswered && !isCorrect
												? 'bg-red-500 text-white'
												: 'bg-yellow-500 text-white'
										)}
										title={
											isAnswered
												? isCorrect
													? 'Правильно'
													: 'Неправильно'
												: 'Не отвечено'
										}
									>
										{index + 1}
									</div>
								);
							})}
						</div>
					</div>

					<div className='text-base sm:text-lg mt-6 text-center'>
						{gradeScore >= 4
							? 'Отличный результат! Вы хорошо подготовлены.'
							: gradeScore >= 3
							? 'Хороший результат! Есть некоторые области для улучшения.'
							: 'Вам стоит повторить материал и попробовать снова.'}
					</div>
				</main>

				<footer className='sticky bottom-0 z-10 bg-background/80 backdrop-blur-sm border-t p-4 flex flex-wrap justify-between gap-2'>
					<Button className='h-10 text-base' onClick={handleReturnHome}>
						На главную
					</Button>
					<Button className='h-10 text-base' onClick={handleShowReview}>
						Просмотр ответов
					</Button>
				</footer>
			</div>
		);
	}

	if (isLoading || !settings) {
		return (
			<div className='min-h-screen flex justify-center items-center p-4'>
				<div className='text-center'>
					<div className='animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4'></div>
					<p>Загрузка экзамена...</p>
				</div>
			</div>
		);
	}

	return (
		<div className='min-h-screen flex flex-col bg-background'>
			<header className='sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b p-4 flex justify-between items-center'>
				<h1 className='text-xl font-semibold'>Тестирование</h1>
				<div className='flex items-center gap-2'>
					<Timer
						initialMinutes={settings.timeTaken}
						onTimeUp={handleTimeUp}
						className='text-base mr-2'
					/>
					<SettingsButton />
				</div>
			</header>

			{questions.length > 0 && (
				<>
					<main className='flex-1 p-4'>
						<div className='flex flex-col sm:flex-row sm:justify-between sm:items-center mt-2 gap-2'>
							<div className='flex items-center gap-2'>
								<User className='h-4 w-4' />
								<span className='text-base'>{settings.studentName}</span>
							</div>
							<div className='flex items-center gap-2'>
								<span className='text-base'>
									Вопрос {currentQuestion + 1} из {questions.length}
								</span>
							</div>
						</div>

						<div className='mt-4'>
							<div className='text-sm text-muted-foreground mb-1'>
								Прогресс: {Math.round(progress)}%
							</div>
							<Progress value={progress} className='h-2' />
						</div>

						<Pagination
							currentIndex={currentQuestion}
							totalItems={questions.length}
							onSelect={handleJumpToQuestion}
							selectedItems={selectedAnswers}
						/>

						<div className='mt-6'>
							<h3 className='text-lg sm:text-xl mb-4'>
								<QuestionTitle title={questions[currentQuestion].title} />
							</h3>
							<div className='text-sm text-muted-foreground mb-2'>
								{selectedAnswers[currentQuestion] !== undefined
									? `Выбран ответ: ${selectedAnswers[currentQuestion] + 1}`
									: 'Ответ не выбран'}
							</div>
							<div className='mt-4 space-y-3'>
								{questions[currentQuestion].answers.map((answer, i) => (
									<AnswerOption
										key={`answer-${i}`}
										index={i}
										text={answer.text}
										isSelected={selectedAnswers[currentQuestion] === i}
										onClick={() => handleAnswerSelect(i)}
									/>
								))}
							</div>
						</div>
					</main>

					<footer className='sticky bottom-0 z-10 bg-background/80 backdrop-blur-sm border-t p-4 flex flex-wrap justify-between gap-2'>
						<Button
							variant='outline'
							className='h-10 text-base'
							onClick={handlePrevQuestion}
							disabled={currentQuestion < 1}
						>
							Назад
						</Button>
						<ConfirmExamFinish
							isFinish={
								Object.keys(selectedAnswers).length === questions.length
							}
							onConfirm={handleFinishExam}
						/>
						{currentQuestion < questions.length - 1 ? (
							<Button className='h-10 text-base' onClick={handleNextQuestion}>
								Далее
							</Button>
						) : (
							<Button className='h-10 text-base' onClick={handleFinishExam}>
								Завершить
							</Button>
						)}
					</footer>
				</>
			)}
		</div>
	);
}
