'use client';

import type React from 'react';

import { SettingsButton } from '@/components/settings-button';
import { Button } from '@/components/ui/button';
import { APP_NAME } from '@/config';
import { isTauri } from '@/lib/tauri-store';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function Home() {
	const router = useRouter();
	const [isOpeningLink, setIsOpeningLink] = useState(false);

	const handleStartExam = () => {
		// Всегда переходим на страницу настроек экзамена, без проверки незавершенного экзамена
		router.push('/exam/settings');
	};

	const handleOpenLink = async (url: string, e: React.MouseEvent) => {
		e.preventDefault();

		if (isOpeningLink) return;
		setIsOpeningLink(true);

		try {
			if (isTauri()) {
				// Используем Tauri API для открытия ссылки в браузере по умолчанию
				const { open } = await import('@tauri-apps/plugin-shell');
				await open(url);
			} else {
				// Для веб-версии открываем в новой вкладке
				window.open(url, '_blank');
			}
		} catch (error) {
			console.error('Ошибка при открытии ссылки:', error);
		} finally {
			setIsOpeningLink(false);
		}
	};

	return (
		<div className='min-h-screen flex flex-col bg-background'>
			<header className='sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b p-4 flex justify-between'>
				<h3>Exam App. {APP_NAME}</h3>
				<SettingsButton />
			</header>

			<main className='flex-1 flex flex-col items-center justify-center p-4'>
				<div className='text-center'>
					<h1 className='text-4xl sm:text-6xl font-bold mb-4'>Привет.</h1>
					<h2 className='text-2xl sm:text-4xl mb-8'>Готов к тестированию?</h2>
					<Button
						className='h-14 px-8 text-xl sm:text-2xl mb-4'
						onClick={handleStartExam}
					>
						Начать!
					</Button>
					<p className='text-gray-400'>
						Обновления приложения (Версия на IOS):{' '}
						<a
							className='text-blue-500 cursor-pointer'
							onClick={e => handleOpenLink('https://t.me/+Att5GS3hnLsyMjJi', e)}
						>
							Телеграм
						</a>
					</p>
				</div>
			</main>
		</div>
	);
}
